package com.itcast.tsc.note.bean;



public class SearchBean {

  public int page; // required
  public String key; // required
public int getPage() {
	return page;
}
public void setPage(int page) {
	this.page = page;
}
public String getKey() {
	return key;
}
public void setKey(String key) {
	this.key = key;
}

}

